-- Dump de la Base de Datos
-- Fecha: jueves 14 julio 2022 - 15:09:22
--
-- Version: 1.1.1, del 14/07/2022 , insidephp@gmail.com
-- Soporte y Updaters: http://insidephp.sytes.net
--
-- Host: `localhost`    Database: `basecelulares`
-- ------------------------------------------------------
-- Server version	5.7.36

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS administrador;
CREATE TABLE `administrador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` varchar(50) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `apellido` varchar(30) DEFAULT NULL,
  `correo` varchar(50) NOT NULL,
  `nive_usua` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `administrador`
--

LOCK TABLES administrador WRITE;
INSERT INTO administrador VALUES(, , , , , , );
INSERT INTO administrador VALUES(, , , , , , );
INSERT INTO administrador VALUES(, , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `areas`
--

DROP TABLE IF EXISTS areas;
CREATE TABLE `areas` (
  `codigo` varchar(5) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `areas`
--

LOCK TABLES areas WRITE;
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
INSERT INTO areas VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `asignaciones`
--

DROP TABLE IF EXISTS asignaciones;
CREATE TABLE `asignaciones` (
  `id_usuario` int(11) NOT NULL,
  `id_equipo` int(11) NOT NULL,
  `T_EQUIPO` varchar(5) NOT NULL,
  `f_asignacion` datetime NOT NULL,
  `SITUACION` varchar(5) NOT NULL,
  UNIQUE KEY `asigna` (`id_usuario`,`id_equipo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `asignaciones`
--

LOCK TABLES asignaciones WRITE;
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
INSERT INTO asignaciones VALUES(, , , , );
UNLOCK TABLES;


--
-- Table structure for table `cargos`
--

DROP TABLE IF EXISTS cargos;
CREATE TABLE `cargos` (
  `codigo` varchar(10) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cargos`
--

LOCK TABLES cargos WRITE;
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
INSERT INTO cargos VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `celulares`
--

DROP TABLE IF EXISTS celulares;
CREATE TABLE `celulares` (
  `ID_EQUIPO` int(10) NOT NULL AUTO_INCREMENT,
  `NUMERO` varchar(15) NOT NULL,
  `C_COMPANIA` varchar(10) NOT NULL,
  `SIMCARD` varchar(50) NOT NULL,
  `IMEI` varchar(50) NOT NULL,
  `C_MARCA` varchar(10) NOT NULL,
  `MODELO` varchar(100) NOT NULL,
  `PLAN` varchar(100) NOT NULL,
  `T_PLAN` varchar(10) NOT NULL,
  `TELEFONIA_IP` varchar(10) NOT NULL,
  `ESTADO_LINEA` varchar(10) NOT NULL,
  `ESTADO_EQUIPO` varchar(10) NOT NULL,
  `F_ALTA` date NOT NULL,
  `F_RECAMBIO` date NOT NULL,
  PRIMARY KEY (`ID_EQUIPO`)
) ENGINE=MyISAM AUTO_INCREMENT=391 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `celulares`
--

LOCK TABLES celulares WRITE;
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
INSERT INTO celulares VALUES(, , , , , , , , , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `cencos`
--

DROP TABLE IF EXISTS cencos;
CREATE TABLE `cencos` (
  `codigo` varchar(10) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cencos`
--

LOCK TABLES cencos WRITE;
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
INSERT INTO cencos VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `compania`
--

DROP TABLE IF EXISTS compania;
CREATE TABLE `compania` (
  `codigo` varchar(10) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compania`
--

LOCK TABLES compania WRITE;
INSERT INTO compania VALUES(, );
INSERT INTO compania VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `computadores`
--

DROP TABLE IF EXISTS computadores;
CREATE TABLE `computadores` (
  `id_equipo` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuarios` int(11) DEFAULT NULL,
  `t_computador` varchar(30) NOT NULL,
  `c_marca` varchar(30) NOT NULL,
  `modelo` varchar(30) NOT NULL,
  `serial` varchar(30) NOT NULL,
  `size_hdd` varchar(10) NOT NULL,
  `t_hdd` varchar(10) NOT NULL,
  `ram` varchar(10) NOT NULL,
  `office` varchar(10) NOT NULL,
  `s_o` varchar(10) NOT NULL,
  `ver_s_o` varchar(10) NOT NULL,
  `procesador` varchar(20) NOT NULL,
  `lic_windows` varchar(4) NOT NULL,
  `lic_office` varchar(4) NOT NULL,
  `f_compra` datetime NOT NULL,
  UNIQUE KEY `idx_computer` (`id_equipo`)
) ENGINE=MyISAM AUTO_INCREMENT=416 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `computadores`
--

LOCK TABLES computadores WRITE;
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, NULL, , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, NULL, , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, NULL, , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, NULL, , , , , , , , , , , , , , );
INSERT INTO computadores VALUES(, , , , , , , , , , , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS empresa;
CREATE TABLE `empresa` (
  `codigo` varchar(5) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empresa`
--

LOCK TABLES empresa WRITE;
INSERT INTO empresa VALUES(, );
INSERT INTO empresa VALUES(, );
INSERT INTO empresa VALUES(, );
INSERT INTO empresa VALUES(, );
INSERT INTO empresa VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `instalaciones`
--

DROP TABLE IF EXISTS instalaciones;
CREATE TABLE `instalaciones` (
  `codigo` varchar(10) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `instalaciones`
--

LOCK TABLES instalaciones WRITE;
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
INSERT INTO instalaciones VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `marcas`
--

DROP TABLE IF EXISTS marcas;
CREATE TABLE `marcas` (
  `codigo` varchar(5) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marcas`
--

LOCK TABLES marcas WRITE;
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
INSERT INTO marcas VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `oficinas`
--

DROP TABLE IF EXISTS oficinas;
CREATE TABLE `oficinas` (
  `codigo` varchar(5) NOT NULL,
  `descripcion` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `oficinas`
--

LOCK TABLES oficinas WRITE;
INSERT INTO oficinas VALUES(, );
INSERT INTO oficinas VALUES(, );
INSERT INTO oficinas VALUES(, );
INSERT INTO oficinas VALUES(, );
INSERT INTO oficinas VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS productos;
CREATE TABLE `productos` (
  `id_productos` int(11) NOT NULL AUTO_INCREMENT,
  `modelo` varchar(50) NOT NULL,
  `descripcion` varchar(400) NOT NULL,
  `marca` varchar(40) NOT NULL,
  `cantidad` int(20) DEFAULT NULL,
  `costo` bigint(30) NOT NULL,
  `p_publico` int(30) NOT NULL,
  `provedor` varchar(30) NOT NULL,
  `estado` varchar(30) NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id_productos`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productos`
--

LOCK TABLES productos WRITE;
INSERT INTO productos VALUES(, , , , , , , , , );
INSERT INTO productos VALUES(, , , , , , , , , );
INSERT INTO productos VALUES(, , , , , , , , , );
UNLOCK TABLES;


--
-- Table structure for table `tusuarios`
--

DROP TABLE IF EXISTS tusuarios;
CREATE TABLE `tusuarios` (
  `codigo` varchar(5) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  UNIQUE KEY `TUsuario` (`codigo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tusuarios`
--

LOCK TABLES tusuarios WRITE;
INSERT INTO tusuarios VALUES(, );
INSERT INTO tusuarios VALUES(, );
INSERT INTO tusuarios VALUES(, );
UNLOCK TABLES;


--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS usuarios;
CREATE TABLE `usuarios` (
  `id_usuarios` int(11) NOT NULL AUTO_INCREMENT,
  `C_TUSUARIO` varchar(5) NOT NULL,
  `NOMBRE` varchar(50) NOT NULL,
  `C_UBICACION` varchar(5) NOT NULL,
  `MAIL` varchar(50) DEFAULT NULL,
  `C_DEPTO` varchar(5) NOT NULL,
  `C_EMPRESA` varchar(5) NOT NULL,
  `CELULAR` varchar(20) NOT NULL,
  `C_INSTALACION` varchar(10) NOT NULL,
  `C_CARGO` varchar(10) NOT NULL,
  `C_CENCO` varchar(10) NOT NULL,
  PRIMARY KEY (`id_usuarios`)
) ENGINE=InnoDB AUTO_INCREMENT=656 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES usuarios WRITE;
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
INSERT INTO usuarios VALUES(, , , , , , , , , , );
UNLOCK TABLES;



-- Dump de la Base de Datos Completo.